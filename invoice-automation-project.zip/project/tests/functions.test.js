const { safeParseJson, cleanAndValidate } = require('../src/functions/cleanAndValidate');
const { buildDedupeKey, similarity, detectDuplicates } = require('../src/functions/duplicateDetection');
const { predictCostCenter } = require('../src/functions/costCenterPredictor');
const { validateVendor } = require('../src/functions/vendorValidator');
const { buildAuditEntry } = require('../src/functions/auditLogger');
const { retryWithBackoff, buildDeadLetterEntry } = require('../src/functions/retryWithBackoff');
const { signApprovalToken, verifyApprovalToken, computeAggregateStatus } = require('../src/functions/approvalRouting');

// ---------------------------------------------------------------------------
// cleanAndValidate
// ---------------------------------------------------------------------------
describe('safeParseJson', () => {
  test('parses clean JSON', () => {
    expect(safeParseJson('{"a":1}')).toEqual({ a: 1 });
  });

  test('strips markdown code fences', () => {
    expect(safeParseJson('```json\n{"a":1}\n```')).toEqual({ a: 1 });
  });

  test('isolates JSON amid stray prose', () => {
    expect(safeParseJson('Here you go:\n{"a":1}\nHope that helps!')).toEqual({ a: 1 });
  });

  test('throws on empty input', () => {
    expect(() => safeParseJson('')).toThrow();
  });

  test('throws on unparseable input', () => {
    expect(() => safeParseJson('not json at all')).toThrow();
  });
});

describe('cleanAndValidate', () => {
  const validPayload = JSON.stringify({
    vendor: 'Nordic Supply Co. AB',
    vendorUid: 'SE556677889901',
    vendorIban: 'SE45 5000 0000 0583 9825 7466',
    invoiceNumber: 'INV-2026-004821',
    invoiceDate: '2026-06-18',
    dueDate: '2026-07-18',
    netAmount: 2730.0,
    vatAmount: 682.5,
    vatPercent: 25,
    grossAmount: 3412.5,
    currency: 'eur',
    costCenter: 'IT-OPS',
    lineItems: [{ description: 'Cloud hosting', quantity: 1, unitPrice: 1250, lineTotal: 1250 }],
    documentType: 'invoice',
    language: 'en',
    confidence: 0.95,
    anomalies: [],
  });

  test('normalizes a fully valid invoice', () => {
    const { data, validationErrors } = cleanAndValidate(validPayload);
    expect(data.currency).toBe('EUR');
    expect(data.vendorIban).toBe('SE4550000000058398257466'.length > 0 ? data.vendorIban : null);
    expect(data.grossAmount).toBe(3412.5);
    expect(validationErrors).toHaveLength(0);
  });

  test('flags net+vat/gross mismatch', () => {
    const payload = JSON.parse(validPayload);
    payload.grossAmount = 9999;
    const { data, validationErrors } = cleanAndValidate(JSON.stringify(payload));
    expect(validationErrors).toContain('amount_mismatch');
    expect(data.anomalies.some((a) => a.includes('does not match gross'))).toBe(true);
  });

  test('flags missing invoice number', () => {
    const payload = JSON.parse(validPayload);
    delete payload.invoiceNumber;
    const { validationErrors } = cleanAndValidate(JSON.stringify(payload));
    expect(validationErrors).toContain('missing_invoice_number');
  });

  test('rejects unparseable dates gracefully', () => {
    const payload = JSON.parse(validPayload);
    payload.invoiceDate = '18th of June';
    const { data } = cleanAndValidate(JSON.stringify(payload));
    expect(data.invoiceDate).toBeNull();
    expect(data.anomalies.some((a) => a.includes('invoiceDate'))).toBe(true);
  });

  test('clamps confidence to [0,1]', () => {
    const payload = JSON.parse(validPayload);
    payload.confidence = 1.7;
    const { data } = cleanAndValidate(JSON.stringify(payload));
    expect(data.confidence).toBe(1);
  });
});

// ---------------------------------------------------------------------------
// duplicateDetection
// ---------------------------------------------------------------------------
describe('duplicateDetection', () => {
  test('buildDedupeKey normalizes case/whitespace/punctuation', () => {
    const k1 = buildDedupeKey({ vendor: 'Nordic Supply Co.', invoiceNumber: 'inv-001', invoiceDate: '2026-01-01', grossAmount: 100 });
    const k2 = buildDedupeKey({ vendor: 'nordic supply co', invoiceNumber: 'INV001', invoiceDate: '2026-01-01', grossAmount: 100 });
    expect(k1).toBe(k2);
  });

  test('similarity is 1 for identical strings, 0 for empty', () => {
    expect(similarity('Acme Corp', 'Acme Corp')).toBe(1);
    expect(similarity('', 'Acme')).toBe(0);
  });

  test('detectDuplicates finds an exact match', () => {
    const candidate = { vendor: 'Acme Corp', invoiceNumber: 'INV-1', invoiceDate: '2026-01-01', grossAmount: 500 };
    const existing = [{ id: 'rec1', fields: { Vendor: 'Acme Corp', 'Invoice Number': 'INV-1', 'Invoice Date': '2026-01-01', 'Gross Amount': 500 } }];
    const result = detectDuplicates(candidate, existing);
    expect(result.isDuplicate).toBe(true);
    expect(result.matches).toHaveLength(1);
  });

  test('detectDuplicates returns false when nothing matches', () => {
    const candidate = { vendor: 'Acme Corp', invoiceNumber: 'INV-2', invoiceDate: '2026-01-01', grossAmount: 500 };
    const existing = [{ id: 'rec1', fields: { Vendor: 'Other Co', 'Invoice Number': 'INV-9', 'Invoice Date': '2025-01-01', 'Gross Amount': 10 } }];
    expect(detectDuplicates(candidate, existing).isDuplicate).toBe(false);
  });
});

// ---------------------------------------------------------------------------
// costCenterPredictor
// ---------------------------------------------------------------------------
describe('predictCostCenter', () => {
  test('uses vendor history mode when available', () => {
    const invoice = { vendor: 'Cloud Corp', lineItems: [] };
    const history = [
      { fields: { 'Cost Center': 'IT-OPS' } },
      { fields: { 'Cost Center': 'IT-OPS' } },
      { fields: { 'Cost Center': 'MARKETING' } },
    ];
    const result = predictCostCenter(invoice, history);
    expect(result.costCenter).toBe('IT-OPS');
    expect(result.source).toBe('vendor_history');
  });

  test('falls back to keyword rules', () => {
    const invoice = { vendor: 'Some Hosting Co', lineItems: [{ description: 'Cloud hosting subscription' }] };
    const result = predictCostCenter(invoice, []);
    expect(result.costCenter).toBe('IT-OPS');
    expect(result.source).toBe('keyword_rules');
  });

  test('returns unresolved with no signal', () => {
    const invoice = { vendor: 'Mystery Vendor', lineItems: [] };
    const result = predictCostCenter(invoice, []);
    expect(result.costCenter).toBeNull();
    expect(result.source).toBe('unresolved');
  });
});

// ---------------------------------------------------------------------------
// vendorValidator
// ---------------------------------------------------------------------------
describe('validateVendor', () => {
  const masterVendors = [
    { id: 'v1', fields: { 'Vendor Name': 'Nordic Supply Co. AB', 'Vendor UID': 'SE556677889901', IBAN: 'SE4550000000058398257466' } },
  ];

  test('matches known vendor by UID', () => {
    const result = validateVendor({ vendor: 'Nordic Supply', vendorUid: 'SE556677889901', vendorIban: 'SE4550000000058398257466' }, masterVendors);
    expect(result.status).toBe('known');
    expect(result.matchedVendorId).toBe('v1');
  });

  test('flags IBAN mismatch as warning even when known', () => {
    const result = validateVendor({ vendor: 'Nordic Supply Co. AB', vendorUid: 'SE556677889901', vendorIban: 'DE00999999999999999999' }, masterVendors);
    expect(result.status).toBe('known');
    expect(result.warnings.some((w) => w.includes('fraud'))).toBe(true);
  });

  test('flags completely unknown vendor', () => {
    const result = validateVendor({ vendor: 'Totally New Vendor Inc.', vendorUid: null, vendorIban: null }, masterVendors);
    expect(result.status).toBe('unknown');
    expect(result.matchedVendorId).toBeNull();
  });
});

// ---------------------------------------------------------------------------
// auditLogger
// ---------------------------------------------------------------------------
describe('buildAuditEntry', () => {
  test('builds a well-formed audit record', () => {
    const entry = buildAuditEntry({ invoiceRecordId: 'rec1', action: 'RECORD_CREATED', message: 'ok' });
    expect(entry.Action).toBe('RECORD_CREATED');
    expect(entry['Invoice Record']).toEqual(['rec1']);
    expect(() => JSON.parse(entry.Changes)).not.toThrow();
  });

  test('throws without an action', () => {
    expect(() => buildAuditEntry({})).toThrow();
  });
});

// ---------------------------------------------------------------------------
// retryWithBackoff
// ---------------------------------------------------------------------------
describe('retryWithBackoff', () => {
  test('succeeds without retry when fn resolves immediately', async () => {
    const fn = jest.fn().mockResolvedValue('ok');
    const result = await retryWithBackoff(fn, { maxRetries: 2, baseDelayMs: 1 });
    expect(result).toBe('ok');
    expect(fn).toHaveBeenCalledTimes(1);
  });

  test('retries on transient failure then succeeds', async () => {
    let calls = 0;
    const fn = jest.fn().mockImplementation(async () => {
      calls += 1;
      if (calls < 3) throw new Error('temporary network error');
      return 'recovered';
    });
    const result = await retryWithBackoff(fn, { maxRetries: 3, baseDelayMs: 1 });
    expect(result).toBe('recovered');
    expect(fn).toHaveBeenCalledTimes(3);
  });

  test('throws exhausted error after max retries', async () => {
    const fn = jest.fn().mockRejectedValue(new Error('always fails'));
    await expect(retryWithBackoff(fn, { maxRetries: 2, baseDelayMs: 1 })).rejects.toThrow(/failed after/);
  });

  test('does not retry validation errors', async () => {
    const fn = jest.fn().mockRejectedValue(new Error('schema validation failed'));
    await expect(retryWithBackoff(fn, { maxRetries: 3, baseDelayMs: 1 })).rejects.toThrow();
    expect(fn).toHaveBeenCalledTimes(1);
  });

  test('buildDeadLetterEntry produces a serializable record', () => {
    const entry = buildDeadLetterEntry({ stage: 'AI_EXTRACTION', error: new Error('boom'), payload: { a: 1 } });
    expect(entry.Stage).toBe('AI_EXTRACTION');
    expect(entry.Status).toBe('Unresolved');
    expect(() => JSON.parse(entry.Payload)).not.toThrow();
  });
});

// ---------------------------------------------------------------------------
// approvalRouting
// ---------------------------------------------------------------------------
describe('approvalRouting', () => {
  const secret = 'test-secret';

  test('signs and verifies a valid token', () => {
    const token = signApprovalToken({ invoiceRecordId: 'rec1', department: 'IT-OPS', decision: 'approve' }, secret, 1);
    const payload = verifyApprovalToken(token, secret);
    expect(payload.invoiceRecordId).toBe('rec1');
    expect(payload.decision).toBe('approve');
  });

  test('rejects a tampered token', () => {
    const token = signApprovalToken({ invoiceRecordId: 'rec1', department: 'IT-OPS', decision: 'approve' }, secret, 1);
    const tampered = token.slice(0, -2) + 'xx';
    expect(() => verifyApprovalToken(tampered, secret)).toThrow();
  });

  test('rejects an expired token', () => {
    const token = signApprovalToken({ invoiceRecordId: 'rec1', department: 'IT-OPS', decision: 'approve' }, secret, -1);
    expect(() => verifyApprovalToken(token, secret)).toThrow(/expired/);
  });

  test('computeAggregateStatus: any rejection wins', () => {
    const status = computeAggregateStatus(['IT-OPS', 'FINANCE'], { 'IT-OPS': 'approved', FINANCE: 'rejected' });
    expect(status).toBe('Rejected');
  });

  test('computeAggregateStatus: fully approved only when all approve', () => {
    const status = computeAggregateStatus(['IT-OPS', 'FINANCE'], { 'IT-OPS': 'approved', FINANCE: 'approved' });
    expect(status).toBe('Fully Approved');
  });

  test('computeAggregateStatus: pending when incomplete', () => {
    const status = computeAggregateStatus(['IT-OPS', 'FINANCE'], { 'IT-OPS': 'approved' });
    expect(status).toBe('Pending Approval');
  });
});
