/**
 * cleanAndValidate.js
 * Safely parses the raw text returned by Gemini, strips any accidental
 * markdown fencing/prose, cleans line items, validates numeric/date fields,
 * and produces a normalized invoice object ready for storage.
 *
 * Never trusts the AI output blindly.
 */

const REQUIRED_FIELDS = [
  'vendor', 'vendorUid', 'vendorIban', 'invoiceNumber', 'invoiceDate',
  'dueDate', 'netAmount', 'vatAmount', 'vatPercent', 'grossAmount',
  'currency', 'costCenter', 'lineItems', 'documentType', 'language',
  'confidence', 'anomalies',
];

const ISO_DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

/**
 * Extracts a JSON object from arbitrary text (handles ```json fences,
 * leading/trailing prose, or a bare object).
 * @param {string} raw
 * @returns {Object}
 */
function safeParseJson(raw) {
  if (typeof raw !== 'string' || !raw.trim()) {
    throw new Error('Empty AI response — cannot parse JSON');
  }

  let candidate = raw.trim();

  // Strip markdown code fences if present.
  const fenceMatch = candidate.match(/```(?:json)?\s*([\s\S]*?)```/i);
  if (fenceMatch) candidate = fenceMatch[1].trim();

  // If there's leading/trailing prose, isolate the outermost { ... }.
  const firstBrace = candidate.indexOf('{');
  const lastBrace = candidate.lastIndexOf('}');
  if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
    candidate = candidate.slice(firstBrace, lastBrace + 1);
  }

  try {
    return JSON.parse(candidate);
  } catch (err) {
    throw new Error(`Failed to parse AI JSON output: ${err.message}`);
  }
}

/**
 * @param {number|string|null} value
 * @returns {number|null}
 */
function toSafeNumber(value) {
  if (value === null || value === undefined || value === '') return null;
  if (typeof value === 'number' && Number.isFinite(value)) return value;
  const cleaned = String(value).replace(/[^0-9.\-]/g, '');
  const num = parseFloat(cleaned);
  return Number.isFinite(num) ? num : null;
}

/**
 * @param {string|null} value
 * @returns {string|null}
 */
function toSafeIsoDate(value) {
  if (!value || typeof value !== 'string') return null;
  const trimmed = value.trim();
  return ISO_DATE_RE.test(trimmed) ? trimmed : null;
}

/**
 * @param {Array|undefined} items
 */
function cleanLineItems(items) {
  if (!Array.isArray(items)) return [];
  return items
    .filter((item) => item && typeof item === 'object' && item.description && String(item.description).trim())
    .map((item) => ({
      description: String(item.description).trim().slice(0, 500),
      quantity: toSafeNumber(item.quantity),
      unitPrice: toSafeNumber(item.unitPrice),
      lineTotal: toSafeNumber(item.lineTotal),
    }));
}

/**
 * Cleans and validates a raw AI object. Never throws for missing/invalid
 * business data — instead records anomalies and nulls the offending field.
 * Throws only if the payload cannot be interpreted as an object at all.
 *
 * @param {string} rawAiText
 * @returns {{data: Object, validationErrors: string[]}}
 */
function cleanAndValidate(rawAiText) {
  const parsed = safeParseJson(rawAiText);
  if (typeof parsed !== 'object' || parsed === null || Array.isArray(parsed)) {
    throw new Error('AI response parsed but is not a JSON object');
  }

  const validationErrors = [];
  const anomalies = Array.isArray(parsed.anomalies) ? [...parsed.anomalies] : [];

  for (const field of REQUIRED_FIELDS) {
    if (!(field in parsed)) {
      anomalies.push(`Missing field "${field}" in AI response — defaulted to null.`);
    }
  }

  const netAmount = toSafeNumber(parsed.netAmount);
  const vatAmount = toSafeNumber(parsed.vatAmount);
  const grossAmount = toSafeNumber(parsed.grossAmount);
  const vatPercent = toSafeNumber(parsed.vatPercent);

  if (netAmount !== null && vatAmount !== null && grossAmount !== null) {
    const expected = Math.round((netAmount + vatAmount) * 100) / 100;
    const actual = Math.round(grossAmount * 100) / 100;
    if (Math.abs(expected - actual) > 0.02) {
      anomalies.push(
        `Net (${netAmount}) + VAT (${vatAmount}) = ${expected} does not match gross (${actual}).`
      );
      validationErrors.push('amount_mismatch');
    }
  }

  if (netAmount !== null && netAmount < 0) {
    anomalies.push('netAmount is negative — flagged for review.');
    validationErrors.push('negative_net_amount');
  }

  if (vatPercent !== null && (vatPercent < 0 || vatPercent > 100)) {
    anomalies.push(`vatPercent ${vatPercent} is out of a plausible 0-100 range.`);
    validationErrors.push('invalid_vat_percent');
  }

  const invoiceDate = toSafeIsoDate(parsed.invoiceDate);
  const dueDate = toSafeIsoDate(parsed.dueDate);
  if (parsed.invoiceDate && !invoiceDate) {
    anomalies.push(`invoiceDate "${parsed.invoiceDate}" could not be normalized to ISO-8601.`);
  }
  if (parsed.dueDate && !dueDate) {
    anomalies.push(`dueDate "${parsed.dueDate}" could not be normalized to ISO-8601.`);
  }
  if (invoiceDate && dueDate && dueDate < invoiceDate) {
    anomalies.push('dueDate is earlier than invoiceDate.');
    validationErrors.push('due_before_invoice_date');
  }

  const invoiceNumber = parsed.invoiceNumber ? String(parsed.invoiceNumber).trim() : null;
  if (!invoiceNumber) {
    anomalies.push('invoiceNumber missing — invoice cannot be safely deduplicated or referenced.');
    validationErrors.push('missing_invoice_number');
  }

  const vendor = parsed.vendor ? String(parsed.vendor).trim() : null;
  if (!vendor) {
    anomalies.push('vendor name missing.');
    validationErrors.push('missing_vendor');
  }

  const confidence = (() => {
    const c = toSafeNumber(parsed.confidence);
    if (c === null) return 0;
    return Math.min(1, Math.max(0, c));
  })();

  const cleaned = {
    vendor,
    vendorUid: parsed.vendorUid ? String(parsed.vendorUid).trim() : null,
    vendorIban: parsed.vendorIban ? String(parsed.vendorIban).trim().replace(/\s+/g, '') : null,
    invoiceNumber,
    invoiceDate,
    dueDate,
    netAmount,
    vatAmount,
    vatPercent,
    grossAmount,
    currency: parsed.currency ? String(parsed.currency).trim().toUpperCase().slice(0, 3) : null,
    costCenter: parsed.costCenter ? String(parsed.costCenter).trim() : null,
    lineItems: cleanLineItems(parsed.lineItems),
    documentType: ['invoice', 'credit_note', 'receipt', 'unknown'].includes(parsed.documentType)
      ? parsed.documentType
      : 'unknown',
    language: parsed.language ? String(parsed.language).trim().toLowerCase().slice(0, 5) : 'unknown',
    confidence,
    anomalies,
  };

  return { data: cleaned, validationErrors };
}

module.exports = { safeParseJson, cleanAndValidate, toSafeNumber, toSafeIsoDate, cleanLineItems };
