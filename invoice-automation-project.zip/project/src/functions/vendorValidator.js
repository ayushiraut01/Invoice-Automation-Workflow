/**
 * vendorValidator.js
 * Validates the extracted vendor against the Airtable "Vendors" master table.
 * Flags unknown vendors instead of silently accepting them (prevents
 * onboarding fraud / typosquatted vendor names from slipping through).
 */

const { normalize, similarity } = require('./duplicateDetection');

/**
 * @param {{vendor:string, vendorUid:string|null, vendorIban:string|null}} invoice
 * @param {Array<{id:string, fields:Object}>} vendorMasterRecords all active
 *        records from the Vendors table
 * @returns {{
 *   status: 'known'|'possible_match'|'unknown',
 *   matchedVendorId: string|null,
 *   confidence: number,
 *   warnings: string[]
 * }}
 */
function validateVendor(invoice, vendorMasterRecords = []) {
  const warnings = [];

  if (!invoice.vendor) {
    return { status: 'unknown', matchedVendorId: null, confidence: 0, warnings: ['No vendor name extracted from invoice.'] };
  }

  // 1. Exact match on Vendor UID (tax ID / registration number) — strongest signal.
  if (invoice.vendorUid) {
    const uidMatch = vendorMasterRecords.find(
      (v) => normalize(v.fields?.['Vendor UID']) === normalize(invoice.vendorUid)
    );
    if (uidMatch) {
      const nameSim = similarity(uidMatch.fields?.['Vendor Name'], invoice.vendor);
      if (nameSim < 0.6) {
        warnings.push('Vendor UID matches master data but vendor name differs significantly — possible impersonation risk.');
      }
      if (invoice.vendorIban && uidMatch.fields?.['IBAN']
        && normalize(uidMatch.fields['IBAN']) !== normalize(invoice.vendorIban)) {
        warnings.push('IBAN on invoice differs from vendor master record — possible payment redirection fraud. Review before approval.');
      }
      return { status: 'known', matchedVendorId: uidMatch.id, confidence: 0.98, warnings };
    }
  }

  // 2. Exact normalized name match.
  const nameMatch = vendorMasterRecords.find(
    (v) => normalize(v.fields?.['Vendor Name']) === normalize(invoice.vendor)
  );
  if (nameMatch) {
    if (invoice.vendorIban && nameMatch.fields?.['IBAN']
      && normalize(nameMatch.fields['IBAN']) !== normalize(invoice.vendorIban)) {
      warnings.push('IBAN on invoice differs from vendor master record — possible payment redirection fraud. Review before approval.');
    }
    return { status: 'known', matchedVendorId: nameMatch.id, confidence: 0.95, warnings };
  }

  // 3. Fuzzy match fallback.
  let bestMatch = null;
  let bestScore = 0;
  for (const v of vendorMasterRecords) {
    const score = similarity(v.fields?.['Vendor Name'], invoice.vendor);
    if (score > bestScore) {
      bestScore = score;
      bestMatch = v;
    }
  }

  if (bestMatch && bestScore >= 0.8) {
    warnings.push(`Vendor name close but not identical to master record "${bestMatch.fields?.['Vendor Name']}" (similarity ${bestScore.toFixed(2)}). Confirm before approval.`);
    return { status: 'possible_match', matchedVendorId: bestMatch.id, confidence: bestScore, warnings };
  }

  warnings.push(`Vendor "${invoice.vendor}" not found in vendor master. Requires onboarding or manual verification before payment.`);
  return { status: 'unknown', matchedVendorId: null, confidence: 0, warnings };
}

module.exports = { validateVendor };
