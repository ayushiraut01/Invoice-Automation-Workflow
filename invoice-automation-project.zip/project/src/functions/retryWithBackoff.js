/**
 * retryWithBackoff.js
 * Generic retry helper with exponential backoff + jitter, used for any
 * network call in the pipeline (Gemini, Airtable, Google Drive, SMTP).
 * On exhaustion, builds a dead-letter payload rather than throwing away
 * the failure silently.
 */

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * @param {Function} fn           async function to execute, receives attempt number (1-based)
 * @param {Object} [opts]
 * @param {number} [opts.maxRetries=3]
 * @param {number} [opts.baseDelayMs=500]
 * @param {number} [opts.maxDelayMs=8000]
 * @param {Function} [opts.isRetryable] (error) => boolean, default: always retryable except validation errors
 * @returns {Promise<*>}
 */
async function retryWithBackoff(fn, opts = {}) {
  const {
    maxRetries = 3,
    baseDelayMs = 500,
    maxDelayMs = 8000,
    isRetryable = (err) => !/validation|schema|unauthorized|401|403/i.test(err?.message || ''),
  } = opts;

  let lastError;
  for (let attempt = 1; attempt <= maxRetries + 1; attempt++) {
    try {
      return await fn(attempt);
    } catch (err) {
      lastError = err;
      const isLastAttempt = attempt === maxRetries + 1;
      if (isLastAttempt || !isRetryable(err)) {
        throw buildExhaustedError(err, attempt);
      }
      const delay = Math.min(maxDelayMs, baseDelayMs * 2 ** (attempt - 1));
      const jitter = Math.random() * delay * 0.25;
      await sleep(delay + jitter);
    }
  }
  throw lastError;
}

function buildExhaustedError(originalError, attempts) {
  const err = new Error(
    `Operation failed after ${attempts} attempt(s): ${originalError.message}`
  );
  err.original = originalError;
  err.attempts = attempts;
  err.exhausted = true;
  return err;
}

/**
 * Builds a dead-letter queue record for Airtable when retries are exhausted.
 * @param {Object} params
 */
function buildDeadLetterEntry({ stage, error, payload = {}, invoiceRecordId = null }) {
  return {
    Stage: stage,
    'Error Message': error?.message || String(error),
    Payload: JSON.stringify(payload).slice(0, 90000),
    'Invoice Record': invoiceRecordId ? [invoiceRecordId] : [],
    Attempts: error?.attempts ?? null,
    Timestamp: new Date().toISOString(),
    Status: 'Unresolved',
  };
}

module.exports = { retryWithBackoff, buildDeadLetterEntry, sleep };
