/**
 * costCenterPredictor.js
 * Rule-based cost-center prediction used when the AI extraction did not find
 * an explicit cost center printed on the invoice. Combines vendor-history
 * lookup (most common cost center previously used for this vendor) with a
 * keyword-based fallback classifier. Always returns a confidence alongside
 * the prediction so it can be treated differently from a human-confirmed value.
 */

const KEYWORD_RULES = [
  { costCenter: 'IT-OPS', keywords: ['software', 'saas', 'subscription', 'cloud', 'hosting', 'license', 'aws', 'azure', 'google cloud'] },
  { costCenter: 'MARKETING', keywords: ['advertising', 'campaign', 'marketing', 'media buy', 'branding', 'seo', 'social media'] },
  { costCenter: 'FACILITIES', keywords: ['rent', 'lease', 'cleaning', 'utilities', 'electricity', 'maintenance', 'office supplies'] },
  { costCenter: 'TRAVEL', keywords: ['flight', 'hotel', 'airfare', 'travel', 'taxi', 'rideshare', 'accommodation'] },
  { costCenter: 'LEGAL', keywords: ['legal', 'attorney', 'law firm', 'compliance', 'notary'] },
  { costCenter: 'HR', keywords: ['recruiting', 'payroll', 'benefits', 'training', 'staffing agency'] },
  { costCenter: 'LOGISTICS', keywords: ['shipping', 'freight', 'courier', 'logistics', 'warehouse', 'customs'] },
];

/**
 * @param {{lineItems: Array, vendor: string}} invoice
 * @param {Array<{fields: Object}>} vendorHistoryRecords previous Airtable
 *        invoice records for this exact vendor, most-recent-first
 * @returns {{costCenter: string|null, confidence: number, source: string}}
 */
function predictCostCenter(invoice, vendorHistoryRecords = []) {
  // 1. Strongest signal: vendor's historical cost center (mode of last N invoices)
  if (vendorHistoryRecords.length > 0) {
    const counts = {};
    for (const record of vendorHistoryRecords) {
      const cc = record.fields?.['Cost Center'];
      if (cc) counts[cc] = (counts[cc] || 0) + 1;
    }
    const entries = Object.entries(counts).sort((a, b) => b[1] - a[1]);
    if (entries.length > 0) {
      const [topCostCenter, topCount] = entries[0];
      const confidence = Math.min(0.95, 0.5 + topCount / vendorHistoryRecords.length * 0.45);
      return { costCenter: topCostCenter, confidence, source: 'vendor_history' };
    }
  }

  // 2. Keyword classification against line item descriptions + vendor name
  const haystack = [
    invoice.vendor || '',
    ...(invoice.lineItems || []).map((li) => li.description || ''),
  ].join(' ').toLowerCase();

  let bestMatch = null;
  let bestScore = 0;

  for (const rule of KEYWORD_RULES) {
    const score = rule.keywords.reduce((acc, kw) => acc + (haystack.includes(kw) ? 1 : 0), 0);
    if (score > bestScore) {
      bestScore = score;
      bestMatch = rule.costCenter;
    }
  }

  if (bestMatch) {
    const confidence = Math.min(0.75, 0.35 + bestScore * 0.15);
    return { costCenter: bestMatch, confidence, source: 'keyword_rules' };
  }

  // 3. No signal available — leave for human reviewer
  return { costCenter: null, confidence: 0, source: 'unresolved' };
}

module.exports = { predictCostCenter, KEYWORD_RULES };
