/**
 * geminiClient.js
 * Thin wrapper around the Google Gemini generateContent REST endpoint.
 * Used either directly in an n8n Code node (Node.js built-in fetch, n8n >=1.30)
 * or as a reference implementation for the HTTP Request node's equivalent config.
 *
 * No OCR, no Claude API — Gemini only.
 */

const DEFAULT_TIMEOUT_MS = 30000;

/**
 * Calls Gemini's generateContent endpoint with a fully-rendered prompt and
 * returns the raw text response (expected to be a JSON string per our prompt
 * contract). Throws on non-2xx / network errors so callers can apply retry logic.
 *
 * @param {Object} params
 * @param {string} params.apiKey
 * @param {string} params.model            e.g. "gemini-2.0-flash"
 * @param {string} params.baseUrl          e.g. "https://generativelanguage.googleapis.com/v1beta"
 * @param {string} params.prompt           fully rendered prompt text
 * @param {number} [params.temperature]
 * @param {number} [params.timeoutMs]
 * @returns {Promise<string>} raw text returned by the model
 */
async function callGemini({
  apiKey,
  model = 'gemini-2.0-flash',
  baseUrl = 'https://generativelanguage.googleapis.com/v1beta',
  prompt,
  temperature = 0.1,
  timeoutMs = DEFAULT_TIMEOUT_MS,
}) {
  if (!apiKey) throw new Error('GEMINI_API_KEY is missing');
  if (!prompt) throw new Error('Prompt text is required');

  const url = `${baseUrl}/models/${model}:generateContent?key=${apiKey}`;

  const body = {
    contents: [
      {
        role: 'user',
        parts: [{ text: prompt }],
      },
    ],
    generationConfig: {
      temperature,
      topP: 0.95,
      maxOutputTokens: 4096,
      responseMimeType: 'application/json',
    },
    safetySettings: [
      { category: 'HARM_CATEGORY_HARASSMENT', threshold: 'BLOCK_ONLY_HIGH' },
      { category: 'HARM_CATEGORY_HATE_SPEECH', threshold: 'BLOCK_ONLY_HIGH' },
    ],
  };

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: controller.signal,
    });

    if (!response.ok) {
      const errText = await response.text().catch(() => '');
      throw new Error(`Gemini API error ${response.status}: ${errText}`);
    }

    const data = await response.json();

    const candidate = data?.candidates?.[0];
    if (!candidate) {
      throw new Error('Gemini API returned no candidates (possibly blocked by safety filters)');
    }
    if (candidate.finishReason && candidate.finishReason !== 'STOP') {
      throw new Error(`Gemini API finished abnormally: ${candidate.finishReason}`);
    }

    const text = candidate?.content?.parts?.map((p) => p.text).join('') ?? '';
    if (!text.trim()) throw new Error('Gemini API returned empty text');

    return text;
  } finally {
    clearTimeout(timeout);
  }
}

/**
 * Renders the extraction prompt template with the given invoice text.
 * @param {string} template
 * @param {string} invoiceText
 */
function renderPrompt(template, invoiceText) {
  return template.replace('{{invoiceText}}', invoiceText.slice(0, 100000));
}

module.exports = { callGemini, renderPrompt };
