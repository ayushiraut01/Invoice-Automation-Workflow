/**
 * duplicateDetection.js
 * Detects whether a newly extracted invoice is a duplicate of an existing
 * Airtable record, using a normalized composite key of
 * (vendor + invoiceNumber + invoiceDate + grossAmount), plus a fuzzy
 * fallback for vendor-name variance.
 */

/**
 * Normalizes a string for stable comparison.
 * @param {string|null} value
 */
function normalize(value) {
  if (!value) return '';
  return String(value)
    .trim()
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, '');
}

/**
 * Builds the composite dedupe key for an invoice.
 * @param {{vendor:string, invoiceNumber:string, invoiceDate:string, grossAmount:number}} invoice
 */
function buildDedupeKey(invoice) {
  const amountKey = invoice.grossAmount !== null && invoice.grossAmount !== undefined
    ? Number(invoice.grossAmount).toFixed(2)
    : 'NA';
  return [
    normalize(invoice.vendor),
    normalize(invoice.invoiceNumber),
    normalize(invoice.invoiceDate),
    amountKey,
  ].join('|');
}

/**
 * Very lightweight Levenshtein-based similarity (0..1) for vendor-name
 * fuzzy matching, used only as a secondary signal — never the sole basis
 * for flagging a duplicate.
 */
function similarity(a, b) {
  const s1 = normalize(a);
  const s2 = normalize(b);
  if (!s1 || !s2) return 0;
  if (s1 === s2) return 1;

  const costs = [];
  for (let i = 0; i <= s1.length; i++) {
    let lastValue = i;
    for (let j = 0; j <= s2.length; j++) {
      if (i === 0) {
        costs[j] = j;
      } else if (j > 0) {
        let newValue = costs[j - 1];
        if (s1.charAt(i - 1) !== s2.charAt(j - 1)) {
          newValue = Math.min(newValue, lastValue, costs[j]) + 1;
        }
        costs[j - 1] = lastValue;
        lastValue = newValue;
      }
    }
    if (i > 0) costs[s2.length] = lastValue;
  }
  const distance = costs[s2.length];
  const maxLen = Math.max(s1.length, s2.length);
  return maxLen === 0 ? 1 : 1 - distance / maxLen;
}

/**
 * Compares a candidate invoice against existing Airtable records (already
 * fetched by the caller via a search filtered to the same vendor/date
 * window, to keep this cheap) and returns duplicate findings.
 *
 * @param {Object} candidate normalized invoice object
 * @param {Array<{id:string, fields:Object}>} existingRecords Airtable records
 * @returns {{isDuplicate: boolean, matches: Array, reason: string|null}}
 */
function detectDuplicates(candidate, existingRecords) {
  const candidateKey = buildDedupeKey(candidate);
  const matches = [];

  for (const record of existingRecords) {
    const f = record.fields || {};
    const existing = {
      vendor: f['Vendor'],
      invoiceNumber: f['Invoice Number'],
      invoiceDate: f['Invoice Date'],
      grossAmount: f['Gross Amount'],
    };

    const existingKey = buildDedupeKey(existing);

    if (existingKey === candidateKey) {
      matches.push({ recordId: record.id, matchType: 'exact', similarity: 1 });
      continue;
    }

    // Secondary signal: same invoice number + same amount, vendor name slightly different
    const sameNumber = normalize(existing.invoiceNumber) === normalize(candidate.invoiceNumber);
    const sameAmount = existing.grossAmount !== undefined
      && candidate.grossAmount !== null
      && Number(existing.grossAmount).toFixed(2) === Number(candidate.grossAmount).toFixed(2);
    const vendorSim = similarity(existing.vendor, candidate.vendor);

    if (sameNumber && sameAmount && vendorSim >= 0.85) {
      matches.push({ recordId: record.id, matchType: 'fuzzy', similarity: vendorSim });
    }
  }

  const isDuplicate = matches.length > 0;
  return {
    isDuplicate,
    matches,
    reason: isDuplicate
      ? `Matches ${matches.length} existing record(s) on vendor+invoiceNumber+date+amount.`
      : null,
  };
}

module.exports = { normalize, buildDedupeKey, similarity, detectDuplicates };
