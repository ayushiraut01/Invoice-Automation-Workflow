/**
 * approvalRouting.js
 * Resolves which approver(s) an invoice must go to based on the department(s)
 * selected during manual review, generates signed single-use approve/reject
 * links, and determines the aggregate status once responses come in.
 */

const crypto = require('crypto');

/**
 * @param {string[]} selectedDepartments  e.g. ["MARKETING", "IT-OPS"]
 * @param {Array<{fields:Object}>} departmentRecords  Airtable Departments table rows
 * @returns {Array<{department:string, approverEmail:string}>}
 */
function resolveApprovers(selectedDepartments, departmentRecords) {
  const approvers = [];
  for (const dept of selectedDepartments || []) {
    const record = departmentRecords.find(
      (d) => (d.fields?.['Department Name'] || '').toUpperCase() === dept.toUpperCase()
    );
    if (record && record.fields?.['Approver Email']) {
      approvers.push({ department: dept, approverEmail: record.fields['Approver Email'] });
    }
  }
  return approvers;
}

/**
 * Signs a payload for use in an approve/reject webhook link so it cannot be
 * tampered with or replayed after expiry.
 *
 * @param {Object} payload  { invoiceRecordId, department, decision }
 * @param {string} secret
 * @param {number} ttlHours
 */
function signApprovalToken(payload, secret, ttlHours = 72) {
  const expiresAt = Date.now() + ttlHours * 3600 * 1000;
  const data = { ...payload, expiresAt };
  const json = JSON.stringify(data);
  const b64 = Buffer.from(json).toString('base64url');
  const hmac = crypto.createHmac('sha256', secret).update(b64).digest('base64url');
  return `${b64}.${hmac}`;
}

/**
 * Verifies and decodes a token produced by signApprovalToken.
 * @param {string} token
 * @param {string} secret
 * @returns {Object} decoded payload
 * @throws if invalid, tampered, or expired
 */
function verifyApprovalToken(token, secret) {
  const [b64, hmac] = String(token || '').split('.');
  if (!b64 || !hmac) throw new Error('Malformed approval token');

  const expectedHmac = crypto.createHmac('sha256', secret).update(b64).digest('base64url');
  const valid = crypto.timingSafeEqual(Buffer.from(hmac), Buffer.from(expectedHmac));
  if (!valid) throw new Error('Approval token signature mismatch — possible tampering');

  const payload = JSON.parse(Buffer.from(b64, 'base64url').toString('utf8'));
  if (Date.now() > payload.expiresAt) throw new Error('Approval token has expired');

  return payload;
}

/**
 * Builds the approve/reject webhook URLs for a given department approver.
 */
function buildApprovalLinks({ invoiceRecordId, department, baseUrl, secret, ttlHours }) {
  const approveToken = signApprovalToken({ invoiceRecordId, department, decision: 'approve' }, secret, ttlHours);
  const rejectToken = signApprovalToken({ invoiceRecordId, department, decision: 'reject' }, secret, ttlHours);
  return {
    approveUrl: `${baseUrl}/webhook/invoice-decision?token=${approveToken}`,
    rejectUrl: `${baseUrl}/webhook/invoice-decision?token=${rejectToken}`,
  };
}

/**
 * Determines the aggregate invoice status given individual department
 * decisions recorded so far.
 * Rule: ANY rejection => Rejected. ALL required departments approved => Fully Approved.
 * Otherwise => Pending Approval.
 *
 * @param {string[]} requiredDepartments
 * @param {Record<string,'approved'|'rejected'>} decisions keyed by department
 */
function computeAggregateStatus(requiredDepartments, decisions) {
  const values = requiredDepartments.map((d) => decisions[d]);
  if (values.some((v) => v === 'rejected')) return 'Rejected';
  if (values.length > 0 && values.every((v) => v === 'approved')) return 'Fully Approved';
  return 'Pending Approval';
}

module.exports = {
  resolveApprovers,
  signApprovalToken,
  verifyApprovalToken,
  buildApprovalLinks,
  computeAggregateStatus,
};
