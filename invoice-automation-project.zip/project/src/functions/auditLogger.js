/**
 * auditLogger.js
 * Builds structured audit-trail entries. Every action in the pipeline
 * (extraction, validation, duplicate check, status change, approval,
 * rejection, error, retry) should produce one of these before being
 * written to the Airtable AuditTrail table.
 */

/**
 * @param {Object} params
 * @param {string} params.invoiceRecordId  Airtable record id of the invoice (or null pre-creation)
 * @param {string} params.action           e.g. "AI_EXTRACTION", "DUPLICATE_CHECK", "STATUS_CHANGE", "APPROVAL", "REJECTION", "ERROR", "RETRY"
 * @param {string} [params.actor]          "system" | user email
 * @param {Object} [params.changes]        before/after diff or relevant payload
 * @param {string} [params.outcome]        "success" | "failure" | "warning"
 * @param {string} [params.message]
 * @returns {Object} Airtable-ready fields object
 */
function buildAuditEntry({
  invoiceRecordId = null,
  action,
  actor = 'system',
  changes = {},
  outcome = 'success',
  message = '',
}) {
  if (!action) throw new Error('audit action is required');

  return {
    'Invoice Record': invoiceRecordId ? [invoiceRecordId] : [],
    Action: action,
    Actor: actor,
    Outcome: outcome,
    Message: message,
    Changes: JSON.stringify(changes ?? {}),
    Timestamp: new Date().toISOString(),
  };
}

/**
 * Structured console/JSON logger for n8n execution logs (separate from the
 * Airtable audit trail — this is for operational observability).
 * @param {string} level 'info'|'warn'|'error'
 * @param {string} event
 * @param {Object} context
 */
function structuredLog(level, event, context = {}) {
  const entry = {
    level,
    event,
    timestamp: new Date().toISOString(),
    ...context,
  };
  const line = JSON.stringify(entry);
  if (level === 'error') console.error(line);
  else if (level === 'warn') console.warn(line);
  else console.log(line);
  return entry;
}

module.exports = { buildAuditEntry, structuredLog };
